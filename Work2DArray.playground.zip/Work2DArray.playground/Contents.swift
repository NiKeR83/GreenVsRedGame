import UIKit

extension Array where Element == [Int] {
    func neighbors(of width: Int, height: Int) -> [Int] {
        var neighbors = [Int]()
        let rows = self.count
        if rows > 0 {
            let columns = self[0].count
            for x in Swift.max(0, width-1)...Swift.min(width+1, rows-1) {
                for y in Swift.max(0, height-1)...Swift.min(height+1, columns-1) {
                    if x != width || y != height {
                        neighbors.append(self[x][y])
                    }
                }
            }
        }
        return neighbors
    }
}

func run(onArray array: [[Int]], iterations: Int) {
    var currentState = array
    var tempState = array

    for _ in 0..<iterations {
        for x in 0..<currentState.count {
            for y in 0..<currentState[x].count {
                let neighbors = currentState.neighbors(of: x, height: y)
                let currentValue = currentState[x][y]
                let greenCount = neighbors.filter { $0 == 1 }.count

                if currentValue == 0 {
                    switch greenCount {
                    case 3, 6:
                        tempState[x][y] = 1
                    default:
                        continue
                    }

                }   else {
                    switch greenCount {
                    case 2, 3, 6:
                        continue
                    default:
                        tempState[x][y] = 0
                    }
                    }
                }
            }
        }
        currentState = tempState
        print(currentState)
    }



var iterations1 = 10
var test1 = [           // Given generation by default
    [0,0,0],
    [1,1,1],
    [0,0,0]
]
run(onArray: test1, iterations: iterations1)

let iterations2 = 15
var test2 = [
    [1,0,0,1],
    [1,1,1,1],
    [0,1,0,0],
    [1,0,1,0]
]
run(onArray: test2, iterations: iterations2)

